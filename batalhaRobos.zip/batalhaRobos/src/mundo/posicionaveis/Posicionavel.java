package mundo.posicionaveis;

public interface Posicionavel {
	public void alteraPosicao(int posI, int posJ);

	public int getI();

	public int getJ();
	
	
}
