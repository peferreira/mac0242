package mv.empilhaveis;

public abstract class Booleano {
    public abstract int valor();
}
