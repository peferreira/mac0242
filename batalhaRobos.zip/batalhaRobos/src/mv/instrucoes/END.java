package mv.instrucoes;

public class END extends Instrucao {
    public END () {
	super();
    }
}