package lab2.fase2.instrucoes;

import lab2.fase2.*;
import java.util.Stack;

public class POP extends Instrucao {
    public POP () {
	super ();
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria) {
	 pilhaDeDados.pop();
    }
}
