package lab2.fase2.instrucoes;

import lab2.fase2.*;
import java.util.Stack;

public class END extends Instrucao {
    public END () {
	super();
    }
}