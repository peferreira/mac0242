package lab2.fase2.instrucoes;

import lab2.fase2.*;
import java.util.Stack;

public class DUP extends Instrucao {
    public DUP () {
	super ();
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria) {
	Empilhavel clone, topo; 
	topo = pilhaDeDados.pop();
	clone = topo.clona();
	pilhaDeDados.push(clone);
	pilhaDeDados.push(topo);
    }
}
