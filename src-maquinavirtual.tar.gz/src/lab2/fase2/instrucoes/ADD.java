package lab2.fase2.instrucoes;

import lab2.fase2.*;
import java.util.Stack;

public class ADD extends Instrucao {
    public ADD () {
	super();
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria) {
	Empilhavel item1 = pilhaDeDados.pop();
	Empilhavel item2 = pilhaDeDados.pop();
	int resultado;
	if ((item1 instanceof Inteiro) && (item2 instanceof Inteiro)) {
	    resultado = ((Inteiro)item2).getInteiro() + ((Inteiro)item1).getInteiro();
	    pilhaDeDados.push(new Inteiro(resultado));
	} else {
	    System.out.println("ADD: Todos os operandos devem ser inteiros!");
	    System.exit(1);
	}
    }
}
