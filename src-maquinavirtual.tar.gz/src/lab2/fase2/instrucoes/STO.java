package lab2.fase2.instrucoes;

import lab2.fase2.*;
import java.util.Stack;

public class STO extends Instrucao {
    public STO (Empilhavel item) {
	super (item);
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria) {
	Empilhavel topo = pilhaDeDados.pop();
	if (argumento instanceof Endereco) {
	    memoria.setMemoria(topo, argumento);
	} else {
	    System.out.println("STO: Endereco invalido!");
	    System.exit(1);
	}
    }
}
