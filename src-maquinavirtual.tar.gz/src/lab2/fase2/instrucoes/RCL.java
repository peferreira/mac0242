package lab2.fase2.instrucoes;

import lab2.fase2.*;
import java.util.Stack;

public class RCL extends Instrucao {
    public RCL (Empilhavel item) {
	super (item);
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria) {
	if (argumento instanceof Endereco) {
	    pilhaDeDados.push(memoria.getMemoria(argumento));
	} else {
	    System.out.println("RCL: Endereco invalido!");
	    System.exit(1);
	}
    }
}
