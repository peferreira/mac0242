package lab2.fase2.instrucoes;

import lab2.fase2.*;
import java.util.Stack;

public class PUSH extends Instrucao {
    public PUSH (Empilhavel item) {
	super (item);
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria) {
	 pilhaDeDados.push(argumento);
    }
}
