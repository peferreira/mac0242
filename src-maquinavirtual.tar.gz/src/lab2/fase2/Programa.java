package lab2.fase2;

import lab2.fase2.instrucoes.*;

public class Programa {
	
    private Instrucao [] vetorPrograma;
    private final int tamanhoPadrao = 1024;
    private int ponteiroPrograma;
    private int numeroDeInstrucoes;
    
    public Programa() {
	vetorPrograma = new Instrucao [tamanhoPadrao];
	ponteiroPrograma = 0;
	numeroDeInstrucoes = 0;
    }

    public Programa(int tamanho) {
	vetorPrograma = new Instrucao [tamanho];
	ponteiroPrograma = 0;
	numeroDeInstrucoes = 0;
    }
    
    public void setPonteiroPrograma (int endereco) {
	ponteiroPrograma = endereco;
    }
    
    public int getPonteiroPrograma() {
	return ponteiroPrograma;
    }

    public void incPonteiroPrograma() {
	ponteiroPrograma++;
    }

    public void addInstrucao(Instrucao codigo) {
	vetorPrograma[numeroDeInstrucoes] = codigo;
	numeroDeInstrucoes++;
    }

    public Instrucao getInstrucao() {
	return vetorPrograma[ponteiroPrograma];
    }

    public int getNumeroDeInstrucoes(){
	return numeroDeInstrucoes;
    }
}
