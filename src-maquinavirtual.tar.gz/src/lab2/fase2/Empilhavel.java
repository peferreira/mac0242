package lab2.fase2;

public interface Empilhavel {
    abstract void print();
    abstract Empilhavel clona();
    abstract boolean equals(Object obj); 
}
