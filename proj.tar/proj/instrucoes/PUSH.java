package proj.instrucoes;

import proj.*;
import proj.empilhaveis.*;
import java.util.Stack;

public class PUSH extends Instrucao {
    public PUSH (Empilhavel item) {
	super (item);
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria, Programa programa) {
	 pilhaDeDados.push(argumento);
	 programa.incPonteiroPrograma();
    }
}
