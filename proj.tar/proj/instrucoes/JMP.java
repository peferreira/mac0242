package proj.instrucoes;

import proj.*;
import proj.empilhaveis.*;
import java.util.Stack;

public class JMP extends Instrucao {
    public JMP (Empilhavel item) {
	super(item);
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria, Programa programa) {
	if (argumento instanceof Endereco) {	
		programa.setPonteiroPrograma(((Endereco)argumento));
	} else {
		System.out.println("JMP: Argumento tem que ser um endereco!");
		System.exit(1);
	}
    }
}
