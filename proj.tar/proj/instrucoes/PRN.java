package proj.instrucoes;

import proj.*;
import proj.empilhaveis.*;
import java.util.Stack;

public class PRN extends Instrucao {
    public PRN () {
	super ();
    } 
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria, Programa programa) {
	Empilhavel topo = pilhaDeDados.pop();
	topo.print();
	programa.incPonteiroPrograma();
    }
}
