package proj.instrucoes;

import proj.*;
import proj.empilhaveis.*;
import java.util.Stack;

public class Instrucao {
    Empilhavel argumento;

    public Instrucao () {
	argumento = null;
    }

    public Instrucao (Empilhavel operando) {
	argumento = operando;
    }

    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria, Programa programa) {
    }
}




	


