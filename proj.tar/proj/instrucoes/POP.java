package proj.instrucoes;

import proj.*;
import proj.empilhaveis.*;
import java.util.Stack;

public class POP extends Instrucao {
    public POP () {
	super ();
    }
    public void executar (Stack<Empilhavel> pilhaDeDados, Memoria memoria, Programa programa) {
	 pilhaDeDados.pop();
	 programa.incPonteiroPrograma();
    }
}
