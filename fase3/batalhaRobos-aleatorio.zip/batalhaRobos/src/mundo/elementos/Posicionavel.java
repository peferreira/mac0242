package mundo.elementos;

import java.awt.Graphics;

public interface Posicionavel {

	void draw(Graphics g, int cx, int cy);
	
}
