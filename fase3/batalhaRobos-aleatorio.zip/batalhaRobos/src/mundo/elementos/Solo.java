package mundo.elementos;

public class Solo {
	public int custo() {
		return 3;
	}
}
