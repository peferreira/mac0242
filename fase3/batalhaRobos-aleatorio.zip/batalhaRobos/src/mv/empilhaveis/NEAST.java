package mv.empilhaveis;

public class NEAST extends Direcao {
	String dir;

	public NEAST() {
		dir = "NE";
	}

	public String getDir() {
		return dir;
	}

}
