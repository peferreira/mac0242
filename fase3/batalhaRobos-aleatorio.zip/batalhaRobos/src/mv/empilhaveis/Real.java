package mv.empilhaveis;

public class Real extends Numero {

	double v;

	public Real(double valor) {
		v = valor;
	}

	public double valor() {
		return v;
	}

}
