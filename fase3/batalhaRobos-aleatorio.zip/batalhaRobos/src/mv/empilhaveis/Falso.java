package mv.empilhaveis;

public class Falso extends Booleano {

	private int v;

	public Falso() {
		v = 0;
	}

	public int valor() {
		return v;
	}
}
