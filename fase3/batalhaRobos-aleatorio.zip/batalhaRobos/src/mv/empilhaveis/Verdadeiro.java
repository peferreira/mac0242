package mv.empilhaveis;

public class Verdadeiro extends Booleano {

	private int v;

	public Verdadeiro() {
		v = 1;
	}

	public int valor() {
		return v;
	}
}
