package mv.empilhaveis;

public class WEST extends Direcao {
	String dir;

	public WEST() {
		dir = "W";
	}

	public String getDir() {
		return dir;
	}
}
