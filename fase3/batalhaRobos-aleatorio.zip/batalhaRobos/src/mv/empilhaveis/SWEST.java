package mv.empilhaveis;

public class SWEST extends Direcao {
	String dir;

	public SWEST() {
		dir = "SW";
	}

	public String getDir() {
		return dir;
	}
}
