package mv.empilhaveis;

public class SEAST extends Direcao {
	String dir;

	public SEAST() {
		dir = "SE";
	}

	public String getDir() {
		return dir;
	}
}
