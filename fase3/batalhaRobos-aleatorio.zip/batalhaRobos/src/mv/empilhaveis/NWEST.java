package mv.empilhaveis;

public class NWEST extends Direcao {
	String dir;

	public NWEST() {
		dir = "NW";
	}

	public String getDir() {
		return dir;
	}
}
