package mv.empilhaveis;

public class EAST extends Direcao {
	String dir;

	public EAST() {
		dir = "E";
	}

	public String getDir() {
		return dir;
	}

}
